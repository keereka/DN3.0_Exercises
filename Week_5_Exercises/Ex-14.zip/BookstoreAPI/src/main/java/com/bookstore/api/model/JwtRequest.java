package com.bookstore.api.model;

public class JwtRequest {
    private String username;
    private String password;

    // getters and setters
}
