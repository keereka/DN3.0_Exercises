package com.bookstore.api.service;

import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    private final MeterRegistry meterRegistry;

    @Autowired
    public BookService(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        this.meterRegistry.counter("book.created").increment(0); // Initialize the counter with 0
    }

    public void createBook() {
        // Simulate book creation logic
        System.out.println("Creating a book...");

        // Increment the custom metric for book creation
        meterRegistry.counter("book.created").increment();
    }
}