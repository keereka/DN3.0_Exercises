package com.bookstore.api;

import com.bookstore.api.model.Book;
import com.bookstore.api.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        return ResponseEntity.ok(bookService.getAllBooks());
    }

    @PostMapping
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        return ResponseEntity.ok(bookService.createBook(book));
    }
    @Autowired
    private BookService bookService;

    @Operation(summary = "Get all books", description = "Fetches all books in the bookstore.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Found the books",
            content = { @Content(mediaType = "application/json",
            schema = @Schema(implementation = Book.class)) }),
        @ApiResponse(responseCode = "404", description = "Books not found",
            content = @Content) })
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        return ResponseEntity.ok(bookService.getAllBooks());
    }

    @Operation(summary = "Create a new book", description = "Adds a new book to the bookstore.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Book created",
            content = { @Content(mediaType = "application/json",
            schema = @Schema(implementation = Book.class)) }),
        @ApiResponse(responseCode = "400", description = "Invalid input",
            content = @Content) })
    @PostMapping
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        return ResponseEntity.ok(bookService.createBook(book));
    }

}
