package k9;

public class StartegyPatternTest {

	public static void main(String[] args) {
		PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876-5432", "Ryan Reynolds");
        PaymentContext paymentContext = new PaymentContext(creditCardPayment);
        paymentContext.executePayment(150.00);
        System.out.println();
        PaymentStrategy payPalPayment = new PayPalPayment("ryanreynolds@gmail.com");
        paymentContext = new PaymentContext(payPalPayment);
        paymentContext.executePayment(200.00);

	}

}
