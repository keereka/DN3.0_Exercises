package k9;

public interface PaymentStartegy {
	void pay(double amount);
}
