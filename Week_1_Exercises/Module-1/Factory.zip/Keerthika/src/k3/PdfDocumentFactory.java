package k3;

public class PdfDocumentFactory extends DocumentFactory {

	public static void main(String[] args) {
		public Document createDocument() {
	        return new ConcretePdfDocument();

	}

}
