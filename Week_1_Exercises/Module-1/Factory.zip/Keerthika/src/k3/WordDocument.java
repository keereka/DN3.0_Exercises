package k3;

public class WordDocument implements Document {

	public static void main(String[] args) {
		public void open() {
	        System.out.println("Opening a Word document.");

	}

}
