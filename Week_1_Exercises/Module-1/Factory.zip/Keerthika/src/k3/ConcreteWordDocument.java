package k3;

public class ConcreteWordDocument extends WordDocument  {

	public static void main(String[] args) {
		 public void open() {
		        System.out.println("Opening a specific Word document.");
	}

}
