package k3;

public abstract class ExcelDocument implements Document{

	public static void main(String[] args) {
		public void open() {
	        System.out.println("Opening an Excel document.");

	}

}
