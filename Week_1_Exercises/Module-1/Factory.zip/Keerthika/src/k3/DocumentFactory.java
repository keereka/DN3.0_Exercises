package k3;

public abstract class DocumentFactory {

	public static void main(String[] args) {
		public abstract Document createDocument();

	}

}
