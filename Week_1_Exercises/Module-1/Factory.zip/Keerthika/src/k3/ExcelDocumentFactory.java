package k3;

public class ExcelDocumentFactory extends DocumentFactory {

	public static void main(String[] args) {
		
		public Document createDocument() {
	        return new ConcreteExcelDocument();
	}

}
