package k3;

public class ConcreteExcelDocument extends ExcelDocument {

	public static void main(String[] args) {
		public void open() {
	        System.out.println("Opening a specific Excel document.");

	}

}
