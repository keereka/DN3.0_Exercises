package k3;

public class WordDocumentFactory extends DocumentFactory{

	public static void main(String[] args) {
		public Document createDocument() {
	        return new ConcreteWordDocument();

	}

}
