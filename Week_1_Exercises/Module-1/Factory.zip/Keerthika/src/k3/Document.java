package k3;

public interface Document {
	void open();
}
