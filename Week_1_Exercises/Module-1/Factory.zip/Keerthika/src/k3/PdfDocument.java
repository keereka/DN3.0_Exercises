package k3;

public abstract class PdfDocument implements Document{

	public static void main(String[] args) {
		public void open() {
	        System.out.println("Opening a PDF document.");

	}

}
