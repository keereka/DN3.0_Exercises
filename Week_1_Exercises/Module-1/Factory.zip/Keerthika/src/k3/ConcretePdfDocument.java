package k3;

public class ConcretePdfDocument extends PdfDocument{

	public static void main(String[] args) {
		public void open() {
	        System.out.println("Opening a specific PDF document.");

	}

}
