package k6;

public interface Notifier {
	void send(String message);
}
