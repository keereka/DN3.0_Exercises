package k7;

public interface Command {
	void execute();
}
