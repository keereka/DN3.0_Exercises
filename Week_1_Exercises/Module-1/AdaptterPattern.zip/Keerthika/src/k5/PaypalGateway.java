package k5;

public class PaypalGateway {

	public void makePayment(double amount) {
        System.out.println("Payment of $" + amount + " processed through PayPal.");

	}

}
