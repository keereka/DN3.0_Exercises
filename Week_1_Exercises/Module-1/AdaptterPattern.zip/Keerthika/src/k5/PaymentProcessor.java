package k5;

public interface PaymentProcessor {
	void processPayment(double amount);
}
