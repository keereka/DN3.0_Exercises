package k5;

public class PaypalAdaptter implements PaymentProcessor {

	private PaypalGateway paypalGateway;
    public PaypalAdapter(PaypalGateway paypalGateway) {
        this.paypalGateway = paypalGateway;
    }
    
    public void processPayment(double amount) {
        paypalGateway.makePayment(amount);
		

	}

}
