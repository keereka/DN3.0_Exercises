package k5;

public class AmazonPayAdaptter implements PaymentProcessor {

	private AmazonPayGateway amazonPayGateway;
    public AmazonPayAdapter(AmazonPayGateway amazonPayGateway) {
        this.amazonPayGateway = amazonPayGateway;
    }
   
    public void processPayment(double amount) {
        amazonPayGateway.pay(amount);	

	}

}
