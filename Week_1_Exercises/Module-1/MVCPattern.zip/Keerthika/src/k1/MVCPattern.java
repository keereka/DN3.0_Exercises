package k1;

public class MVCPattern {

	public static void main(String[] args) {
		Student student = new Student("Rahul", "12345", "A+");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(student, view);
        controller.updateView();
        controller.setStudentName("Sachin");
        controller.setStudentId("67890");
        controller.setStudentGrade("B+");
        controller.updateView();

	}

}
