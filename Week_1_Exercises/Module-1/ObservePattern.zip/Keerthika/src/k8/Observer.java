package k8;

public interface Observer {
	 void update(double stockPrice);
}
