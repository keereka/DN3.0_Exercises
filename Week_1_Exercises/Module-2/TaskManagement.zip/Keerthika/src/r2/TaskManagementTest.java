package r2;

public class TaskManagementTest {

	public static void main(String[] args) {
		TaskManagementSystem tms = new TaskManagementSystem();

        tms.addTask(new Task(1, "Task One", "Incomplete"));
        tms.addTask(new Task(2, "Task Two", "Complete"));
        tms.addTask(new Task(3, "Task Three", "Incomplete"));

        System.out.println("All Tasks:");
        tms.traverseTasks();

        System.out.println("\nSearching for Task ID 2:");
        Task task = tms.searchTaskById(2);
        if (task != null) {
            System.out.println("Found: " + task);
        } else {
            System.out.println("Task not found.");
        }

        System.out.println("\nDeleting Task ID 1:");
        tms.deleteTaskById(1);

        System.out.println("\nAll Tasks After Deletion:");
        tms.traverseTasks();

	}

}
