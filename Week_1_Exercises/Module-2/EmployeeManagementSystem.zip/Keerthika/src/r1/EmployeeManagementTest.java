package r1;

public class EmployeeManagementTest {

	public static void main(String[] args) {
		EmployeeManagementSystem ems = new EmployeeManagementSystem();

        ems.addEmployee(new Employee(1, "Rahul", "Manager", 75000));
        ems.addEmployee(new Employee(2, "Ajay", "Developer", 60000));
        ems.addEmployee(new Employee(3, "Kishore", "Designer", 55000));

        System.out.println("All Employees:");
        ems.traverseEmployees();

        System.out.println("\nSearching for Employee ID 2:");
        Employee employee = ems.searchEmployeeById(2);
        if (employee != null) {
            System.out.println("Found: " + employee);
        } else {
            System.out.println("Employee not found.");
        }

        System.out.println("\nDeleting Employee ID 1:");
        ems.deleteEmployeeById(1);

        System.out.println("\nAll Employees After Deletion:");
        ems.traverseEmployees();

	}

}
