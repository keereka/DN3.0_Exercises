package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.projection.EmployeeProjection;

import com.example.EmployeeManagementSystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;
import com.example.EmployeeManagementSystem.projection.EmployeeSummary;


@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Using method name conventions
    List<Employee> findByDepartmentName(String departmentName);

    Employee findByEmail(String email);

    List<Employee> findByNameContainingIgnoreCase(String namePart);

    // Using @Query annotation for custom queries
    @Query("SELECT d FROM Department d WHERE d.name = ?1")
    List<Department> findDepartmentsByName(String name);

    @Query("SELECT COUNT(e) FROM Employee e WHERE e.department.id = ?1")
    Long countEmployeesInDepartment(Long departmentId);

    // Executing named queries using @Query annotation
    @Query(name = "Employee.findAllByDepartmentName")
    List<Employee> findAllByDepartmentName(String name);

    @Query(name = "Employee.findAllOrderedByName")
    List<Employee> findAllOrderedByName();
    Page<Employee> findAll(Pageable pageable);
    
    @Query("SELECT e.id AS id, e.name AS name, e.email AS email, d.name AS departmentName " +
            "FROM Employee e JOIN e.department d")
     List<EmployeeProjection> findAllEmployeeProjections();
    
    @Query("SELECT new com.example.employeemanagementsystem.projection.EmployeeSummary(e.id, e.name, e.email, d.name) " +
            "FROM Employee e JOIN e.department d")
     List<EmployeeSummary> findAllEmployeeSummaries();
}
