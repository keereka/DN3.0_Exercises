package com.example.EmployeeManagementSystem.entity;

import javax.persistence.*;

@Entity
@NamedQueries({
    @NamedQuery(
        name = "Employee.findAllByDepartmentName",
        query = "SELECT e FROM Employee e WHERE e.department.name = :name"
    ),
    @NamedQuery(
        name = "Employee.findAllOrderedByName",
        query = "SELECT e FROM Employee e ORDER BY e.name ASC"
    )
})
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

    // Getters and Setters
}
