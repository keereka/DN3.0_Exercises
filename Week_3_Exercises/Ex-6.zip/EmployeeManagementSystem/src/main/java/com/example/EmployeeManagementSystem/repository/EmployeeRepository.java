package com.example.EmployeeManagementSystem.repository;


import com.example.EmployeeManagementSystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Using method name conventions
    List<Employee> findByDepartmentName(String departmentName);

    Employee findByEmail(String email);

    List<Employee> findByNameContainingIgnoreCase(String namePart);

    // Using @Query annotation for custom queries
    @Query("SELECT d FROM Department d WHERE d.name = ?1")
    List<Department> findDepartmentsByName(String name);

    @Query("SELECT COUNT(e) FROM Employee e WHERE e.department.id = ?1")
    Long countEmployeesInDepartment(Long departmentId);

    // Executing named queries using @Query annotation
    @Query(name = "Employee.findAllByDepartmentName")
    List<Employee> findAllByDepartmentName(String name);

    @Query(name = "Employee.findAllOrderedByName")
    List<Employee> findAllOrderedByName();
    Page<Employee> findAll(Pageable pageable);
}
