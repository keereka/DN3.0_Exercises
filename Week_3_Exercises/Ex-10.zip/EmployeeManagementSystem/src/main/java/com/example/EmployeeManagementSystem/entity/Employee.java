package com.example.EmployeeManagementSystem.entity;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.*;

@Entity
@Table(name = "employees")
@TypeDefs({
    @TypeDef(name = "myCustomType", typeClass = MyCustomType.class)
})
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String email;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

    @Type(type = "myCustomType")
    private String customField;

    // Getters and Setters
}
