package com.example.EmployeeManagementSystem.service;

import com.example.EmployeeManagementSystem.entity.Employee;
import java.util.List;

public interface EmployeeService {
    void saveEmployee(Employee employee);
    Employee findEmployeeById(Long id);
    List<Employee> findAllEmployees();
    void deleteEmployee(Long id);
    void batchInsertEmployees(List<Employee> employees);
}
