package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.Department;

import java.util.List;
import com.example.EmployeeManagementSystem.projection.DepartmentProjection;

import com.example.EmployeeManagementSystem.projection.DepartmentSummary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {

    // Custom query to find departments with a specific name
    @Query("SELECT d FROM Department d WHERE d.name = ?1")
    List<Department> findDepartmentsByName(String name);

    // Custom query to count employees in a department by department id
    @Query("SELECT COUNT(e) FROM Employee e WHERE e.department.id = ?1")
    Long countEmployeesInDepartment(Long departmentId);
    
    @Query("SELECT d.id AS id, d.name AS name FROM Department d")
    List<DepartmentProjection> findAllDepartmentProjections();
    
    @Query("SELECT new com.example.employeemanagementsystem.projection.DepartmentSummary(d.id, d.name) " +
            "FROM Department d")
     List<DepartmentSummary> findAllDepartmentSummaries();
}