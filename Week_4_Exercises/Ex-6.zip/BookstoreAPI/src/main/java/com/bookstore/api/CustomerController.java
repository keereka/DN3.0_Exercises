package com.bookstore.api;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


@RestController
@RequestMapping("/customers")
public class CustomerController {

    @PostMapping
    public Customer createCustomer(@RequestBody Customer customer) {
        // Logic to save customer (simulated here)
        customer.setId(1L); // Simulate ID generation
        return customer;
    }
    @PostMapping("/register")
    public String registerCustomer(@RequestParam String name,
                                   @RequestParam String email,
                                   @RequestParam MultipartFile profilePicture) {
        // Simulate registration process
        String message = "Customer registered with name: " + name + " and email: " + email;
        // Save the file and customer details (not implemented)
        return message;
    }
}
