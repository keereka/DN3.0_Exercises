package com.bookstore.api;

import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/books")
public class BookController {

    private List<Book> books = new ArrayList<>(); // Simulating a database
    
    @GetMapping("/{id}")
    public Book getBookById(@PathVariable int id) {
        return books.stream()
                     .filter(book -> book.getId() == id)
                     .findFirst()
                     .orElse(null);
    }
    
    // GET method to filter books by title and author
    @GetMapping("/filter")
    public List<Book> getBooksByFilter(@RequestParam(required = false) String title,
                                       @RequestParam(required = false) String author) {
        return books.stream()
                .filter(book -> (title == null || book.getTitle().equalsIgnoreCase(title)) &&
                                (author == null || book.getAuthor().equalsIgnoreCase(author)))
                .collect(Collectors.toList());
    }

    // GET method to retrieve all books
    @GetMapping
    public List<Book> getAllBooks() {
        return books;
    }

    // POST method to add a new book
    @PostMapping
    public Book addBook(@RequestBody Book book) {
        books.add(book);
        return book;
    }

    // PUT method to update an existing book
    @PutMapping("/{id}")
    public Book updateBook(@PathVariable int id, @RequestBody Book book) {
        books.set(id, book);
        return book;
    }

    // DELETE method to remove a book
    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable int id) {
        books.remove(id);
    }
}
