package com.library.service;

public class BookService {
    public void addBook() {
        System.out.println("Book added.");
    }
}
